'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { randomBytes, createHash, scryptSync, timingSafeEqual } = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const C = require('./public/core.cjs');

const hash = s => createHash('sha256').update(s).digest('hex');
const token = () => randomBytes(32).toString('base64url');
const roles = new Set(['viewer', 'editor', 'blocked']);
const factoryFields = ['name','products','city','business','lead','contact','phone','wechat','email','address','workers','area','lines','capacity','specialty','moq','payment','risks','owner','checked','source','other','notes'];
const childFields = {
  stocks: ['product','quantity','price','currency','moq','status','lead','date','model','notes'],
  chats: ['date','summary','needed','timing','exactDate','action','task','owner','ours','theirs','notes'],
  contacts: ['name','position','phone','wechat','email','address','notes']
};
const choices = {
  business: ['','factory','trade','both','unsure','other'], lead: ['','days3','days7','days14','days30','over30','unsure','other'],
  advantages: ['price','quality','delivery','small','custom','other'], status: ['','in','limited','order','unsure','other'],
  needed: ['','yes','no','unsure','other'], timing: ['','today','days3','week1','weeks2','exact','unsure','other'], task: ['','notstarted','progress','done','cancelled','other']
};
class AppError extends Error { constructor(status, message, code) { super(message); this.status=status; this.code=code; } }
const fail = (status, message, code) => { throw new AppError(status, message, code); };
function text(v, max=10000) { if(v===undefined||v===null)return ''; if(typeof v!=='string'||v.length>max)fail(400,'Invalid text / 文字无效或过长'); return v.trim(); }
function checkChoice(key, value) { if(!choices[key].includes(value))fail(400,'Invalid choice / 选项无效'); return value; }
function pick(data, fields, numeric=[]) {
  if(!data||typeof data!=='object'||Array.isArray(data))fail(400,'Invalid form / 表单无效');
  const result={};
  for(const key of fields) {
    if(numeric.includes(key)) { const value=data[key]; if(value===undefined||value===null||value==='')result[key]=null; else if(typeof value!=='number'||!Number.isFinite(value)||value<0)fail(400,'Invalid number / 数字无效'); else result[key]=value; }
    else result[key]=text(data[key]);
  }
  return result;
}
function validBackup(data) {
  try { const out=C.validate(data); for(const f of out.factories) { checkChoice('business',f.business||''); checkChoice('lead',f.lead||''); if(f.advantages.some(x=>!choices.advantages.includes(x)))fail(400,'Invalid advantage / 优势选项无效');
    for(const[k, fields]of Object.entries(childFields))for(const item of f[k]) { for(const key of fields) if(!['quantity','price','moq'].includes(key))text(item[key]); if(k==='stocks'){checkChoice('status',item.status||'');checkChoice('lead',item.lead||'');} if(k==='chats'){for(const key of['needed','timing','task'])checkChoice(key,item[key]||'');} }
  } return out; } catch(e) { if(e instanceof AppError)throw e; fail(400,'Invalid backup; records unchanged / 备份无效，资料未更改'); }
}
function createApp(options={}) {
  const env=options.env||process.env;
  const rawBase=env.BASE_URL||'',parsedBase=rawBase?new URL(rawBase):null;
  if(parsedBase&&parsedBase.protocol!=='https:')throw Error('BASE_URL must be HTTPS');
  if(parsedBase&&(parsedBase.pathname!=='/'||parsedBase.search||parsedBase.hash||parsedBase.username||parsedBase.password))throw Error('BASE_URL must be an HTTPS origin without a path or credentials');
  const base=parsedBase?.origin||'';
  const authMode=(env.AUTH_MODE||'wecom').trim().toLowerCase();
  if(!['wecom','local'].includes(authMode))throw Error('AUTH_MODE must be wecom or local');
  const localAdminUser=(env.LOCAL_ADMIN_USER||'admin').trim().toLowerCase();
  const localAdminPassword=env.LOCAL_ADMIN_PASSWORD||'';
  if(authMode==='local'&&(!/^[a-z0-9._-]{3,32}$/.test(localAdminUser)||localAdminPassword.length<14))throw Error('For local mode, set LOCAL_ADMIN_USER (3–32 letters/numbers/._-) and LOCAL_ADMIN_PASSWORD (at least 14 characters)');
  const admins=new Set((env.WECOM_ADMIN_IDS||'').split(',').map(x=>x.trim()).filter(Boolean));
  if(authMode==='local')admins.add(localAdminUser);
  const timeZone=env.TIME_ZONE||'Asia/Shanghai'; new Intl.DateTimeFormat('en-CA',{timeZone});
  const configured=!!(base&&env.WECOM_CORP_ID&&env.WECOM_AGENT_ID&&env.WECOM_APP_SECRET&&(authMode==='local'||admins.size));
  const ready=authMode==='local'||configured;
  const dbPath=options.dbPath||env.DATABASE_PATH||path.join(__dirname,'data','factory.sqlite');
  if(dbPath!==':memory:')fs.mkdirSync(path.dirname(dbPath),{recursive:true,mode:0o700});
  const db=new DatabaseSync(dbPath);
  if(dbPath!==':memory:')fs.chmodSync(dbPath,0o600);
  db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON;');
  db.exec(`CREATE TABLE IF NOT EXISTS workspace(id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS members(user_id TEXT PRIMARY KEY,role TEXT NOT NULL CHECK(role IN ('viewer','editor','blocked')),last_seen TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL,csrf TEXT NOT NULL,expires INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS oauth_states(token_hash TEXT PRIMARY KEY,expires INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS local_accounts(username TEXT PRIMARY KEY,salt TEXT NOT NULL,password_hash TEXT NOT NULL,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,user_id TEXT NOT NULL,action TEXT NOT NULL,target TEXT NOT NULL);`);
  db.prepare('INSERT OR IGNORE INTO workspace(id,payload) VALUES(1,?)').run(JSON.stringify(C.blank()));
  // A damaged database is never silently reset.
  C.validate(JSON.parse(db.prepare('SELECT payload FROM workspace WHERE id=1').get().payload));
  const clock=options.clock||(()=>new Date());
  const now=()=>clock().getTime(),stamp=()=>clock().toISOString();
  const today=()=>{const p=new Intl.DateTimeFormat('en-CA',{timeZone,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(clock());const part=k=>p.find(x=>x.type===k).value;return `${part('year')}-${part('month')}-${part('day')}`;};
  const passwordDigest=(password,salt)=>scryptSync(password,salt,64).toString('hex');
  if(authMode==='local') {
    const existing=db.prepare('SELECT username FROM local_accounts WHERE username=?').get(localAdminUser);
    if(!existing) { const salt=randomBytes(16).toString('hex'); db.prepare('INSERT INTO local_accounts(username,salt,password_hash,created_at) VALUES(?,?,?,?)').run(localAdminUser,salt,passwordDigest(localAdminPassword,salt),stamp()); }
    db.prepare("INSERT OR IGNORE INTO members(user_id,role,last_seen) VALUES(?,'viewer',?)").run(localAdminUser,stamp());
  }
  const state=()=>C.validate(JSON.parse(db.prepare('SELECT payload FROM workspace WHERE id=1').get().payload));
  const fetcher=options.fetcher||fetch;
  let accessToken='',tokenExpires=0;
  async function wecomJSON(url) {
    try { const r=await fetcher(url,{signal:AbortSignal.timeout(12000)}); if(!r.ok)fail(502,'WeCom connection failed / 企业微信连接失败'); const body=await r.json();if(body.errcode)fail(502,`WeCom sign-in failed (code ${Number(body.errcode)||0}). Ask your administrator to check application credentials, trusted domain and server IP. / 企业微信登录失败，请管理员检查应用凭据、可信域名和服务器IP。`);return body; }
    catch(e){if(e instanceof AppError)throw e;fail(502,'WeCom connection unavailable; try again / 企业微信连接暂时不可用，请重试');}
  }
  async function getAccessToken() { if(accessToken&&now()<tokenExpires)return accessToken; const url=new URL('https://qyapi.weixin.qq.com/cgi-bin/gettoken');url.searchParams.set('corpid',env.WECOM_CORP_ID);url.searchParams.set('corpsecret',env.WECOM_APP_SECRET);const body=await wecomJSON(url);if(typeof body.access_token!=='string'||!body.access_token)fail(502,'WeCom returned no access token / 企业微信未返回有效令牌');accessToken=body.access_token;tokenExpires=now()+(Math.max(60,Number(body.expires_in)||7200)-60)*1000;return accessToken; }
  const sessionCookieName=base?'__Host-factory-session':'factory-session';
  function currentSession(req) {
    const cookies=Object.fromEntries((req.headers.cookie||'').split(';').map(x=>{const i=x.indexOf('=');return [x.slice(0,i).trim(),x.slice(i+1)];}));
    const raw=cookies[sessionCookieName];if(!raw||!/^[A-Za-z0-9_-]{43}$/.test(raw))return null;
    const found=db.prepare('SELECT * FROM sessions WHERE token_hash=? AND expires>?').get(hash(raw),now());if(!found)return null;
    const member=db.prepare('SELECT role FROM members WHERE user_id=?').get(found.user_id);
    const role=admins.has(found.user_id)?'admin':member?.role||'viewer';
    if(role==='blocked')fail(403,'Your access has been removed / 您的权限已被取消','blocked');
    return {userId:found.user_id,role,csrf:found.csrf,tokenHash:found.token_hash};
  }
  const publicSession=s=>({userId:s.userId,role:s.role,csrf:s.csrf});
  const cookie=(name,value,maxAge)=>`${name}=${value}; Path=/; Max-Age=${maxAge}; HttpOnly; ${base?'Secure; ':''}SameSite=Lax`;
  function sameOrigin(req){ if(base)return req.headers.origin===base; try{return new URL(req.headers.origin).host===req.headers.host;}catch{return false;} }
  function headers(res,type='application/json; charset=utf-8') {
    res.setHeader('Content-Type',type);res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
    if(base)res.setHeader('Strict-Transport-Security','max-age=31536000');
  }
  const json=(res,status,body)=>{headers(res);res.statusCode=status;res.end(JSON.stringify(body));};
  const redirect=(res,url,cookies)=>{headers(res);res.statusCode=302;res.setHeader('Location',url);if(cookies)res.setHeader('Set-Cookie',cookies);res.end();};
  async function body(req) { let size=0,parts=[];for await(const chunk of req){size+=chunk.length;if(size>10*1024*1024)fail(413,'File or form exceeds 10 MB / 文件或表单超过10MB');parts.push(chunk);}try{return JSON.parse(Buffer.concat(parts).toString('utf8'));}catch{fail(400,'Invalid JSON / 数据格式无效');} }
  function writeGuard(req,session,admin=false) {
    if(!session)fail(401,'Open this app in WeCom and sign in / 请在企业微信打开并登录','signin');
    if(admin&&session.role!=='admin'||!admin&&!['admin','editor'].includes(session.role))fail(403,'You do not have permission for this action / 您没有此操作权限');
    if(!sameOrigin(req)||req.headers['x-csrf-token']!==session.csrf)fail(403,'Request could not be verified; refresh the app / 无法验证请求，请刷新应用');
    if(!(req.headers['content-type']||'').startsWith('application/json'))fail(415,'Use JSON content / 数据格式必须为JSON');
  }
  function edit(session,request) {
    db.exec('BEGIN IMMEDIATE');
    try {
      const old=state();if(!Number.isSafeInteger(request.baseRevision)||request.baseRevision!==old.revision)fail(409,'Someone else saved changes. Keep your notes and refresh before saving again. / 其他人已保存修改，请保留未保存文字，刷新后再保存。','conflict');
      const id=text(request.id,80),data=request.data;let next,recordId=id;
      switch(request.type) {
        case 'factory.save': {const input=pick(data,factoryFields);checkChoice('business',input.business);checkChoice('lead',input.lead);if(data.advantages!==undefined&&(!Array.isArray(data.advantages)||data.advantages.length>20))fail(400,'Invalid advantages / 优势无效');input.advantages=[...new Set((data.advantages||[]).map(x=>text(x,80)))];if(input.advantages.some(x=>!choices.advantages.includes(x)))fail(400,'Invalid advantages / 优势无效');const r=C.saveFactory(old,input,id,stamp());next=r.state;recordId=r.id;break;}
        case 'child.save': {const kind=text(request.kind,30);if(!childFields[kind])fail(400,'Invalid record type / 记录类型无效');const input=pick(data,childFields[kind],kind==='stocks'?['quantity','price','moq']:[]);if(data.id)input.id=text(data.id,80);if(kind==='stocks'){checkChoice('status',input.status);checkChoice('lead',input.lead);}if(kind==='chats'){for(const k of['needed','timing','task'])checkChoice(k,input[k]);if(input.timing==='exact'&&!input.exactDate&&input.needed!=='no')fail(400,'Choose an exact date or a different timing option / 请填写指定日期或改选其他时间');}next=C.saveChild(old,id,kind,input,stamp(),today());break;}
        case 'factory.delete': {const f=C.factory(old,id);if(f.status!=='active')fail(400,'Factory is already in Trash / 工厂已在回收站');if(request.confirmName!==f.name)fail(400,'Factory name changed; refresh and confirm again / 工厂名称已改变，请刷新并再次确认');next=C.setDeleted(old,id,true,stamp());break;}
        case 'factory.restore': {if(C.factory(old,id).status!=='deleted')fail(400,'Factory is not in Trash / 工厂不在回收站');next=C.setDeleted(old,id,false,stamp());break;}
        case 'factory.purge': {if(session.role!=='admin')fail(403,'Only an administrator can delete permanently / 只有管理员可永久删除');if(request.confirmName!==C.factory(old,id).name)fail(400,'Factory name does not match / 工厂名称不匹配');next=C.purge(old,id);break;}
        case 'backup.restore': {if(session.role!=='admin')fail(403,'Only an administrator can restore a full backup / 只有管理员可恢复完整备份');next=C.restoreBackup(old,validBackup(request.backup));break;}
        default: fail(400,'Unknown action / 未知操作');
      }
      next=C.validate(next);next.revision=old.revision+1;const payload=JSON.stringify(next);if(Buffer.byteLength(payload)>8*1024*1024)fail(413,'Database size limit reached; ask the administrator / 数据库达到容量限制，请联系管理员');
      db.prepare('UPDATE workspace SET payload=? WHERE id=1').run(payload);
      db.prepare('INSERT INTO audit(at,user_id,action,target) VALUES(?,?,?,?)').run(stamp(),session.userId,request.type,recordId);
      db.exec('COMMIT');return {state:next,recordId,session:publicSession(session),today:today(),timeZone};
    } catch(e) {db.exec('ROLLBACK');if(e instanceof AppError)throw e;fail(400,e.message||'Could not save; records unchanged / 保存失败，资料未更改');}
  }
  const publicFiles={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/core.js':'core.cjs','/style.css':'style.css'};
  const loginLimit=new Map();
  async function handle(req,res) {
    try {
      const url=new URL(req.url,'http://localhost'),route=url.pathname;
      if(route==='/healthz'&&req.method==='GET')return json(res,200,{ok:true,wecomConfigured:configured,authMode,ready});
      if(route==='/auth/config'&&req.method==='GET')return json(res,200,{mode:authMode,ready});
      if(route==='/auth/local/login'&&req.method==='POST') {
        if(authMode!=='local')fail(404,'Local sign-in is disabled / 本地账号登录未启用');
        if(!sameOrigin(req))fail(403,'Request could not be verified / 无法验证请求');
        const key=req.socket.remoteAddress,limit=loginLimit.get(key)||{n:0,until:now()+60000};if(now()>limit.until){limit.n=0;limit.until=now()+60000;}if(++limit.n>12)fail(429,'Too many sign-in attempts; wait a minute / 登录过于频繁，请稍后重试');loginLimit.set(key,limit);
        const input=await body(req),username=text(input.username,32).toLowerCase(),password=text(input.password,256);
        const account=db.prepare('SELECT * FROM local_accounts WHERE username=?').get(username);
        if(!account||!password||!timingSafeEqual(Buffer.from(passwordDigest(password,account.salt),'hex'),Buffer.from(account.password_hash,'hex')))fail(401,'Account or password is incorrect / 账号或密码不正确');
        const member=db.prepare('SELECT role FROM members WHERE user_id=?').get(username);if(member?.role==='blocked'&&!admins.has(username))fail(403,'Your access has been removed / 您的权限已被取消','blocked');
        db.prepare("INSERT OR IGNORE INTO members(user_id,role,last_seen) VALUES(?,'viewer',?)").run(username,stamp());
        db.prepare('UPDATE members SET last_seen=? WHERE user_id=?').run(stamp(),username);
        const session=token(),csrf=token();db.prepare('INSERT INTO sessions(token_hash,user_id,csrf,expires) VALUES(?,?,?,?)').run(hash(session),username,csrf,now()+8*60*60000);
        headers(res);res.statusCode=200;res.setHeader('Set-Cookie',cookie(sessionCookieName,session,8*3600));res.end(JSON.stringify({ok:true,session:publicSession({userId:username,role:admins.has(username)?'admin':member?.role||'viewer',csrf})}));return;
      }
      if(route==='/auth/wecom/start'&&req.method==='GET') {
        if(authMode!=='wecom')fail(404,'This site is currently using team accounts / 当前网站使用团队账号登录');
        if(!configured)fail(503,'WeCom is not connected yet. An administrator must configure the application and HTTPS domain. / 尚未连接企业微信，请管理员配置应用和HTTPS域名。');
        const key=req.socket.remoteAddress,t=loginLimit.get(key)||{n:0,until:now()+60000};if(now()>t.until){t.n=0;t.until=now()+60000;}if(++t.n>30)fail(429,'Too many sign-in attempts; wait a minute / 登录过于频繁，请稍后重试');loginLimit.set(key,t);
        db.prepare('DELETE FROM oauth_states WHERE expires<=?').run(now());db.prepare('DELETE FROM sessions WHERE expires<=?').run(now());
        const raw=token();db.prepare('INSERT INTO oauth_states(token_hash,expires) VALUES(?,?)').run(hash(raw),now()+5*60000);
        const to=new URL('https://open.weixin.qq.com/connect/oauth2/authorize');for(const[k,v]of Object.entries({appid:env.WECOM_CORP_ID,agentid:env.WECOM_AGENT_ID,redirect_uri:base+'/auth/wecom/callback',response_type:'code',scope:'snsapi_base',state:raw}))to.searchParams.set(k,v);to.hash='wechat_redirect';return redirect(res,to.toString(),[cookie('__Host-factory-oauth',raw,300)]);
      }
      if(route==='/auth/wecom/callback'&&req.method==='GET') {
        if(authMode!=='wecom')fail(404,'This site is currently using team accounts / 当前网站使用团队账号登录');
        if(!configured)fail(503,'WeCom is not configured / 企业微信尚未配置');
        const raw=url.searchParams.get('state')||'',code=url.searchParams.get('code')||'';
        const savedCookie=(req.headers.cookie||'').split(';').find(x=>x.trim().startsWith('__Host-factory-oauth='))?.trim().slice('__Host-factory-oauth='.length);
        if(!/^[A-Za-z0-9_-]{43}$/.test(raw)||raw!==savedCookie||!code||code.length>512)fail(403,'Sign-in expired or invalid. Open the app again in WeCom. / 登录已过期或无效，请在企业微信重新打开。');
        const valid=db.prepare('DELETE FROM oauth_states WHERE token_hash=? AND expires>? RETURNING token_hash').get(hash(raw),now());if(!valid)fail(403,'Sign-in expired; open the app again / 登录已过期，请重新打开');
        const infoURL=new URL('https://qyapi.weixin.qq.com/cgi-bin/auth/getuserinfo');infoURL.searchParams.set('access_token',await getAccessToken());infoURL.searchParams.set('code',code);const info=await wecomJSON(infoURL);
        if(typeof info.UserId!=='string'||!info.UserId||info.UserId.length>128)fail(403,'This app is for members of your company only / 此应用仅供本企业成员使用');
        const member=db.prepare('SELECT role FROM members WHERE user_id=?').get(info.UserId);if(member?.role==='blocked'&&!admins.has(info.UserId))fail(403,'Your access has been removed / 您的权限已被取消');
        db.prepare("INSERT INTO members(user_id,role,last_seen) VALUES(?,'viewer',?) ON CONFLICT(user_id) DO UPDATE SET last_seen=excluded.last_seen").run(info.UserId,stamp());
        const session=token(),csrf=token();db.prepare('INSERT INTO sessions(token_hash,user_id,csrf,expires) VALUES(?,?,?,?)').run(hash(session),info.UserId,csrf,now()+8*60*60000);
        return redirect(res,base+'/',[cookie(sessionCookieName,session,8*3600),cookie('__Host-factory-oauth','',0)]);
      }
      if(req.method==='GET'&&publicFiles[route]) {const file=publicFiles[route],type=file.endsWith('.html')?'text/html; charset=utf-8':file.endsWith('.css')?'text/css; charset=utf-8':'text/javascript; charset=utf-8';headers(res,type);return res.end(fs.readFileSync(path.join(__dirname,'public',file)));}
      if(!route.startsWith('/api/'))return json(res,404,{error:'Page not found / 页面不存在'});
      if(!ready)fail(503,'WeCom is not connected yet / 尚未连接企业微信','setup');
      const session=currentSession(req);if(!session)fail(401,'Open this app in WeCom to sign in / 请在企业微信打开并登录','signin');
      if(route==='/api/state'&&req.method==='GET')return json(res,200,{state:state(),session:publicSession(session),today:today(),timeZone});
      if(route==='/api/backup'&&req.method==='GET'){if(session.role!=='admin')fail(403,'Only administrators can download full backups / 只有管理员可下载完整备份');headers(res);res.setHeader('Content-Disposition',`attachment; filename="Supplier_Backup_${today()}.json"`);return res.end(JSON.stringify(state()));}
      if(route==='/api/action'&&req.method==='POST'){const input=await body(req),live=currentSession(req);writeGuard(req,live);return json(res,200,edit(live,input));}
      if(route==='/api/logout'&&req.method==='POST'){if(!sameOrigin(req)||req.headers['x-csrf-token']!==session.csrf)fail(403,'Request could not be verified / 无法验证请求');db.prepare('DELETE FROM sessions WHERE token_hash=?').run(session.tokenHash);headers(res);res.setHeader('Set-Cookie',cookie(sessionCookieName,'',0));return json(res,200,{ok:true});}
      if(route==='/api/team'&&req.method==='GET'){if(session.role!=='admin')fail(403,'Administrator access required / 需要管理员权限');const members=db.prepare('SELECT user_id,role,last_seen FROM members ORDER BY user_id').all().map(x=>({...x,role:admins.has(x.user_id)?'admin':x.role}));return json(res,200,{members,audit:db.prepare('SELECT at,user_id,action,target FROM audit ORDER BY id DESC LIMIT 100').all()});}
      if(route==='/api/team'&&req.method==='POST'){const input=await body(req),live=currentSession(req);writeGuard(req,live,true);const id=text(input.userId,128);if(!id||!roles.has(input.role)||admins.has(id))fail(400,'Choose an employee and a valid role / 请选择员工和有效权限');db.exec('BEGIN IMMEDIATE');try{db.prepare('INSERT INTO members(user_id,role,last_seen) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET role=excluded.role').run(id,input.role,stamp());if(input.role==='blocked')db.prepare('DELETE FROM sessions WHERE user_id=?').run(id);db.prepare('INSERT INTO audit(at,user_id,action,target) VALUES(?,?,?,?)').run(stamp(),live.userId,'team.role',id);db.exec('COMMIT');}catch(e){db.exec('ROLLBACK');throw e;}return json(res,200,{ok:true});}
      if(route==='/api/team/accounts'&&req.method==='POST'){const input=await body(req),live=currentSession(req);writeGuard(req,live,true);if(authMode!=='local')fail(400,'Create accounts in WeCom before switching auth mode / 切换登录模式前请在企业微信创建账号');const username=text(input.username,32).toLowerCase(),password=text(input.password,256),role=input.role;if(!/^[a-z0-9._-]{3,32}$/.test(username))fail(400,'Username must be 3–32 letters, numbers, dot, underscore or hyphen / 账号需为3–32位英文、数字、点、下划线或连字符');if(password.length<12)fail(400,'Password must be at least 12 characters / 密码至少12位');if(!['viewer','editor'].includes(role))fail(400,'Choose view-only or editor access / 请选择查看或编辑权限');if(admins.has(username))fail(409,'This username is reserved for an administrator / 此账号保留给管理员');const salt=randomBytes(16).toString('hex');try{db.prepare('INSERT INTO local_accounts(username,salt,password_hash,created_at) VALUES(?,?,?,?)').run(username,salt,passwordDigest(password,salt),stamp());db.prepare('INSERT INTO members(user_id,role,last_seen) VALUES(?,?,?)').run(username,role,stamp());db.prepare('INSERT INTO audit(at,user_id,action,target) VALUES(?,?,?,?)').run(stamp(),live.userId,'team.account.create',username);}catch(e){if(String(e.message).includes('UNIQUE'))fail(409,'This username already exists / 账号已存在');throw e;}return json(res,200,{ok:true});}
      if(route==='/api/team/password'&&req.method==='POST'){const input=await body(req),live=currentSession(req);writeGuard(req,live,true);if(authMode!=='local')fail(400,'Local accounts are disabled / 本地账号未启用');const username=text(input.username,32).toLowerCase(),password=text(input.password,256);if(!/^[a-z0-9._-]{3,32}$/.test(username)||password.length<12)fail(400,'Choose an account and a password of at least 12 characters / 请选择账号并设置至少12位密码');const salt=randomBytes(16).toString('hex');const result=db.prepare('UPDATE local_accounts SET salt=?,password_hash=? WHERE username=?').run(salt,passwordDigest(password,salt),username);if(!result.changes)fail(404,'Account not found / 账号不存在');db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash<>?').run(username,live.tokenHash);db.prepare('INSERT INTO audit(at,user_id,action,target) VALUES(?,?,?,?)').run(stamp(),live.userId,'team.account.password',username);return json(res,200,{ok:true});}
      return json(res,404,{error:'Action not found / 操作不存在'});
    } catch(e) {
      const message=e instanceof AppError?e.message:'Server error; records unchanged / 服务器错误，资料未更改';
      if(!res.headersSent&&(req.url||'').startsWith('/auth/')){
        const escape=s=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
        headers(res,'text/html; charset=utf-8');res.statusCode=e.status||500;res.end(`<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="stylesheet" href="/style.css"><title>WeCom sign-in / 企业微信登录</title><main><div class="panel"><h1>WeCom sign-in / 企业微信登录</h1><p class="notice">${escape(message)}</p><a class="loginbutton" href="/">Back to the app / 返回应用</a></div></main></html>`);
      }else if(!res.headersSent)json(res,e.status||500,{error:message,code:e.code||'error'});else res.end();
    }
  }
  const server=http.createServer(handle);server.headersTimeout=20000;server.requestTimeout=30000;
  return {server,db,close:()=>db.close()};
}
module.exports={createApp};
if(require.main===module) {const app=createApp();const port=Number(process.env.PORT||3000);app.server.listen(port,'0.0.0.0',()=>console.log(`Factory Database listening on port ${port}; no supplier records are seeded.`));for(const event of['SIGTERM','SIGINT'])process.on(event,()=>app.server.close(()=>{app.close();process.exit(0);}));}
