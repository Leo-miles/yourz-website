const SupplierCore=(()=>{
 const version=1,blank=()=>({version,nextId:1,revision:0,factories:[],retired:[]});
 const clean=v=>String(v??'').trim(),clone=x=>JSON.parse(JSON.stringify(x));
 const dateValid=v=>!v||/^\d{4}-\d{2}-\d{2}$/.test(v)&&new Date(v+'T12:00:00Z').toISOString().slice(0,10)===v;
 const plusDays=(iso,n)=>{if(!dateValid(iso)||!iso)throw Error('Invalid date / 日期无效');const d=new Date(iso+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);};
 const validate=s=>{
  if(!s||s.version!==version||!Array.isArray(s.factories)||!Array.isArray(s.retired)||!Number.isSafeInteger(s.nextId)||s.nextId<1||!Number.isSafeInteger(s.revision)||s.revision<0)throw Error('Invalid backup format / 备份格式无效');
  const ids=new Set();let max=0;
  for(const f of s.factories){if(!f||!/^F\d{6}$/.test(f.id)||ids.has(f.id)||!['active','deleted'].includes(f.status)||!clean(f.name)||!clean(f.products)||!clean(f.city)||!Array.isArray(f.advantages)||!Array.isArray(f.stocks)||!Array.isArray(f.chats)||!Array.isArray(f.contacts))throw Error('Invalid or duplicate factory / 工厂资料无效或编号重复');for(const[k,v]of Object.entries(f))if(!['stocks','chats','contacts','advantages'].includes(k)&&(typeof v!=='string'||v.length>10000))throw Error('Invalid factory field / 工厂字段无效');if(!dateValid(f.checked??''))throw Error('Invalid verification date / 核实日期无效');if(!f.advantages.every(v=>typeof v==='string'))throw Error('Invalid advantages / 优势选项无效');ids.add(f.id);max=Math.max(max,Number(f.id.slice(1)));
   for(const list of[f.stocks,f.chats,f.contacts]){const childIds=new Set();for(const child of list){if(!child||typeof child.id!=='string'||!/^[A-Za-z0-9-]+$/.test(child.id)||childIds.has(child.id))throw Error('Invalid linked record / 关联资料无效');childIds.add(child.id);for(const key of['date','due','exactDate','anchor'])if(!dateValid(child[key]??''))throw Error('Invalid record date / 记录日期无效');for(const key of['quantity','price','moq'])if(child[key]!==undefined&&child[key]!==null&&child[key]!==''&&(!Number.isFinite(child[key])||child[key]<0))throw Error('Invalid number / 数字无效');}}
  }
  for(const id of s.retired){if(!/^F\d{6}$/.test(id))throw Error('Invalid retired ID / 历史编号无效');max=Math.max(max,Number(id.slice(1)));}
  if(s.nextId<=max)throw Error('Backup ID counter is invalid / 备份编号计数无效');return clone(s);
 };
 const factory=(s,id)=>{const f=s.factories.find(x=>x.id===id);if(!f)throw Error('Factory not found / 未找到工厂');return f;};
 const saveFactory=(s,data,id,stamp)=>{const n=clone(s);for(const k of['name','products','city'])if(!clean(data[k]))throw Error('Fill name, products and city / 请填名称、产品和城市');let f;
  if(id){f=factory(n,id);if(f.status!=='active')throw Error('Restore before editing / 请先恢复再编辑');}else{if(n.nextId>999999)throw Error('ID capacity reached / 编号已用完');f={id:'F'+String(n.nextId++).padStart(6,'0'),status:'active',createdAt:stamp,stocks:[],chats:[],contacts:[]};n.factories.push(f);}
  const fields=['name','products','city','business','lead','contact','phone','wechat','email','address','workers','area','lines','capacity','specialty','moq','payment','risks','owner','checked','source','other','notes'];for(const k of fields)f[k]=clean(data[k]);f.advantages=Array.isArray(data.advantages)?data.advantages.map(clean):[];f.updatedAt=stamp;validate(n);return {state:n,id:f.id};
 };
 const childId=()=>globalThis.crypto?.randomUUID?.()??('R'+Date.now().toString(36)+Math.random().toString(36).slice(2));
 const saveChild=(s,id,kind,data,stamp,today)=>{const n=clone(s),f=factory(n,id);if(f.status!=='active'||!['stocks','chats','contacts'].includes(kind))throw Error('Cannot edit this record / 无法编辑此记录');const old=data.id?f[kind].find(x=>x.id===data.id):null;if(data.id&&!old)throw Error('Linked record missing / 关联记录不存在');const item={...data,id:old?.id??childId(),updatedAt:stamp};
  if(kind==='chats'){const changed=!old||old.timing!==item.timing||old.exactDate!==item.exactDate;if(changed){item.anchor=today;item.due=item.timing==='exact'?(item.exactDate||''):Object.hasOwn({today:0,days3:3,week1:7,weeks2:14},item.timing)?plusDays(today,{today:0,days3:3,week1:7,weeks2:14}[item.timing]):'';}else{item.anchor=old.anchor;item.due=old.due;}if(item.needed==='no')item.due='';else if(old?.needed==='no'&&item.needed!=='no'&&!changed)item.due=item.timing==='exact'?(item.exactDate||''):Object.hasOwn({today:0,days3:3,week1:7,weeks2:14},item.timing)?plusDays(item.anchor||today,{today:0,days3:3,week1:7,weeks2:14}[item.timing]):'';}
  if(old)f[kind][f[kind].findIndex(x=>x.id===old.id)]=item;else f[kind].push(item);f.updatedAt=stamp;validate(n);return n;
 };
 const setDeleted=(s,id,deleted,stamp)=>{const n=clone(s),f=factory(n,id);f.status=deleted?'deleted':'active';f.deletedAt=deleted?stamp:'';f.updatedAt=stamp;return n;};
 const purge=(s,id)=>{const n=clone(s),f=factory(n,id);if(f.status!=='deleted')throw Error('Only Trash records can be permanently deleted / 只能永久删除回收站中的记录');n.factories=n.factories.filter(x=>x.id!==id);n.retired=[...new Set([...n.retired,id])];return n;};
 const open=c=>c.needed!=='no'&&!['done','cancelled'].includes(c.task)&&(c.needed==='yes'||!!clean(c.action));
 const followups=s=>s.factories.filter(f=>f.status==='active').flatMap(f=>f.chats.filter(open).map(c=>({factoryId:f.id,name:f.name,...c}))).sort((a,b)=>(a.due||'9999').localeCompare(b.due||'9999'));
 const search=(s,q,deleted=false)=>s.factories.filter(f=>f.status===(deleted?'deleted':'active')&&JSON.stringify(f).toLocaleLowerCase().includes(clean(q).toLocaleLowerCase()));
 const restoreBackup=(current,incoming)=>{const n=validate(incoming);n.nextId=Math.max(n.nextId,current.nextId);n.retired=[...new Set([...n.retired,...current.retired])];n.revision=current.revision;return validate(n);};
 const csv=rows=>'\ufeff'+rows.map(row=>row.map(v=>{let t=String(v??'');if(/^\s*[=+@-]/.test(t))t="'"+t;return '"'+t.replaceAll('"','""')+'"';}).join(',')).join('\r\n');
 return {blank,validate,clone,clean,plusDays,factory,saveFactory,saveChild,setDeleted,purge,followups,search,restoreBackup,csv,open};
})();
export default SupplierCore;
