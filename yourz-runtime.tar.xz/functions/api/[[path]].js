import { onRequest } from '../../src/handler.js';
export { onRequest };
